﻿using Microsoft.Extensions.Options;

namespace Redstone.Sdk.Server.Authentication
{
    public class RedstoneAuthenticationPostConfigureOptions : IPostConfigureOptions<RedstoneAuthenticationOptions>
    {
        public void PostConfigure(string name, RedstoneAuthenticationOptions options)
        {
            //if (string.IsNullOrEmpty(options.Realm))
            //{
            //    throw new InvalidOperationException("Realm must be provided in options");
            //}
        }
    }
}