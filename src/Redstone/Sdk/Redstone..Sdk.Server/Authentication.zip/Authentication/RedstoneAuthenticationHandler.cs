﻿using System;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using IAuthenticationService = Redstone.Sdk.Server.Services.IAuthenticationService;

namespace Redstone.Sdk.Server.Authentication
{
    public static class RedstoneContants
    {
        public const string RedstoneHexClaim = "RedstoneHex";
        public const string RedstoneTokenClaim = "RedstoneToken";
    }

    public class RedstoneAuthenticationHandler : AuthenticationHandler<RedstoneAuthenticationOptions>
    {
        private const string RedstoneHeaderName = "Redstone";
        private const string RedstoneHexSchemeName = "hex";
        private const string RedstoneTokenSchemeName = "token";
        private readonly IAuthenticationService _authenticationService;

        public RedstoneAuthenticationHandler(
            IOptionsMonitor<RedstoneAuthenticationOptions> options,
            ILoggerFactory logger,
            UrlEncoder encoder,
            ISystemClock clock,
            IAuthenticationService authenticationService)
            : base(options, logger, encoder, clock)
        {
            this._authenticationService = authenticationService;
        }

        protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
        {
            if (!this.Request.Headers.ContainsKey(RedstoneHeaderName))
            {
                //Authorization header not in request
                return AuthenticateResult.NoResult();
            }

            if (!AuthenticationHeaderValue.TryParse(this.Request.Headers[RedstoneHeaderName], out AuthenticationHeaderValue headerValue))
            {
                //Invalid Authorization header
                return AuthenticateResult.NoResult();
            }

            if (RedstoneHexSchemeName.Equals(headerValue.Scheme, StringComparison.OrdinalIgnoreCase))
            {
                var hex = headerValue.Parameter;

                bool isValid = this._authenticationService.IsValidHex(hex);

                if (!isValid)
                {
                    return AuthenticateResult.Fail("Invalid hex");
                }

                return AddClaimAndGenerateTicket(RedstoneContants.RedstoneTokenClaim, hex);
            }
            else if (RedstoneTokenSchemeName.Equals(headerValue.Scheme, StringComparison.OrdinalIgnoreCase))
            {
                var token = headerValue.Parameter;

                //bool isValid = await this._authenticationService.IsValidToke(token);

                //if (!isValid)
                //{
                //    return AuthenticateResult.Fail("Invalid token");
                //}

                return AddClaimAndGenerateTicket(RedstoneContants.RedstoneTokenClaim, token);
            }
            else
            {
                return AuthenticateResult.NoResult();
            }
        }

        private AuthenticateResult AddClaimAndGenerateTicket(string name, string value)
        {
            var claims = new[] {new Claim(name, value)};
            var identity = new ClaimsIdentity(claims, this.Scheme.Name);
            var principal = new ClaimsPrincipal(identity);
            var ticket = new AuthenticationTicket(principal, this.Scheme.Name);
            return AuthenticateResult.Success(ticket);
        }

        //protected override async Task HandleChallengeAsync(AuthenticationProperties properties)
        //{
        //    //this.Response.Headers["WWW-Authenticate"] = $"Basic realm=\"{this.Options.Realm}\", charset=\"UTF-8\"";
        //    await base.HandleChallengeAsync(properties);
        //}
    }
}