﻿using System;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using IAuthenticationService = Redstone.Sdk.Server.Services.IAuthenticationService;

namespace Redstone.Sdk.Server.Authentication
{
    public static class RedstoneAuthenticationExtensions
    {
        public static AuthenticationBuilder AddRedstone<TAuthService>(this AuthenticationBuilder builder, string authenticationScheme)
            where TAuthService : class, IAuthenticationService
        {
            return AddRedstone<TAuthService>(builder, authenticationScheme, _ => { });
        }

        public static AuthenticationBuilder AddRedstone<TAuthService>(this AuthenticationBuilder builder, string authenticationScheme, Action<RedstoneAuthenticationOptions> configureOptions)
            where TAuthService : class, IAuthenticationService
        {
            builder.Services.AddSingleton<IPostConfigureOptions<RedstoneAuthenticationOptions>, RedstoneAuthenticationPostConfigureOptions>();
            builder.Services.AddTransient<IAuthenticationService, TAuthService>();

            return builder.AddScheme<RedstoneAuthenticationOptions, RedstoneAuthenticationHandler>(
                authenticationScheme, configureOptions);
        }
    }

    public class RedstoneTokenException : Exception { }
}