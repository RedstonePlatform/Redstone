﻿namespace Redstone.Sdk.Server.Authentication
{
    public static class RedstoneAuthenticationSchemes
    {
        public const string Hex = "RedstoneHex";
        public const string Token = "RedstoneToken";
    }
}