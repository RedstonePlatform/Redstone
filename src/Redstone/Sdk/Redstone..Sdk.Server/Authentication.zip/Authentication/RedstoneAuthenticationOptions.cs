﻿using Microsoft.AspNetCore.Authentication;

namespace Redstone.Sdk.Server.Authentication
{
    public class RedstoneAuthenticationOptions : AuthenticationSchemeOptions
    {
        //public string Realm { get; set; }
    }
}