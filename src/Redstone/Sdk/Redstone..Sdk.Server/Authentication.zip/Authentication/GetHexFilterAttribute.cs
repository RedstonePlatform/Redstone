﻿//using Microsoft.AspNetCore.Mvc.Filters;

//namespace Redstone.Server.Auth.Hex
//{
//    internal class GetHexFilterAttribute : ActionFilterAttribute
//    {
//        public override void OnActionExecuting(ActionExecutingContext actionContext)
//        {
//            actionContext.HttpContext.Request.Headers.TryGetValue("Authorization", out var authorizationToken);
//        }
//    }
//}
