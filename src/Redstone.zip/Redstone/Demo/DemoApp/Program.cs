using System;
using System.Threading.Tasks;
using Redstone.Sdk.Models;
using Redstone.Sdk.Services;

namespace Redstone.DemoApp
{
    public class Program
    {
        public static void Main(string[] args)
        {
            MainAsync(args).Wait();
        }

        public static async Task MainAsync(string[] args)
        {
            var token = "";

            // try api without token
            Console.WriteLine("Calling API without payment");
            var result = await CallApiAsync(token);
            Console.WriteLine($"Result: {result}");

            Console.WriteLine("Making payment");
            var transaction = await BuildTransactionAsync(args);
            token = await GetApiTokenAsync(transaction.Hex);
            Console.WriteLine($"Token: {token}");

            Console.WriteLine("Calling API After payment");
            result = await CallApiAsync(token);
            Console.WriteLine($"Result: {result}");

            Console.ReadKey();
        }

        private static async Task<WalletBuildTransactionModel> BuildTransactionAsync(string[] args)
        {
            var walletService = new WalletService();
            var transaction = await walletService.BuildTransactionAsync(new BuildTransactionRequest
            {
                AccountName = "account 0",
                Amount = "1",
                AllowUnconfirmed = true,
                DestinationAddress = "TLX2UxwiqoANX34f91Y3CCRD8atySdBsBL",
                FeeAmount = "0.005",
                FeeType = "low",
                Password = "redstone1",
                WalletName = "redstone1",
                ShuffleOutputs = true,
            });

            Console.WriteLine($"Here is your hex: {transaction.Hex}");
            return transaction;
        }

        public static async Task<string> GetApiTokenAsync(string hex)
        {
            return await HttpClientHelper.HttpGet("http://localhost:55888/v1/token", new[] { ("Redstone", $"hex {hex}") });
        }

        public static async Task<string> CallApiAsync(string token)
        {
            try
            {
                return await HttpClientHelper.HttpGet("http://localhost:55888/v1/demo", new[] { ("Redstone", $"token {token}") });
            }
            catch(Exception e)
            {
                return e.Message;
            }            
        }
    }
}
