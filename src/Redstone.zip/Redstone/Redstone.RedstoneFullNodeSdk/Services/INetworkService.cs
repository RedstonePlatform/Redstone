﻿namespace Redstone.Sdk.Server.Services
{
    public interface INetworkService
    {
        void InitializeNetwork(bool testNet);
    }
}